﻿namespace Domain
{
    public interface IEntity
    {
        int Id { get; }
    }
}