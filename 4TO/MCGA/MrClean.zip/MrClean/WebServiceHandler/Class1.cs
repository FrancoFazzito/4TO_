﻿using System;

namespace WebServiceHandler
{
    public class Class1
    {
    }
}
