﻿namespace MrClean
{
    public class Respuesta
    {
        public decimal ImporteTotal { get; set; }
        public decimal CostoEnvio { get; set; }
    }
}