//------------------------------------------------------------------------------
// <generado autom�ticamente>
//     Este c�digo fue generado por una herramienta.
//
//     Los cambios en este archivo podr�an causar un comportamiento incorrecto y se perder�n si
//     se vuelve a generar el c�digo. 
// </generado autom�ticamente>
//------------------------------------------------------------------------------

namespace MrClean
{


    public partial class ViewSwitcher
    {
    }
}
