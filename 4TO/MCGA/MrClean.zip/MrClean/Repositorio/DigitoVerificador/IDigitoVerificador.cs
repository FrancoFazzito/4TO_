﻿namespace Repositorio
{
    public interface IDigitoVerificador
    {
        string ObtenerDigitoHorizontal(int id);

        string ObtenerDigitoVertical();
    }
}