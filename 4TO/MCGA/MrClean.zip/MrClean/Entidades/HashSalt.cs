﻿namespace Entidades
{
    public class HashSalt
    {
        public string PassHashed { get; set; }
        public string Salt { get; set; }
    }
}