﻿using System;

namespace Entidades
{
    [Serializable]
    public enum TipoEvento
    {
        Error, Warning, Message
    }
}