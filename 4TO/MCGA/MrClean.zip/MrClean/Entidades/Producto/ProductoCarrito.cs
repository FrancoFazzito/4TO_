﻿namespace Entidades
{
    public class ProductoCarrito
    {
        public int Cantidad { get; set; }
        public string Nombre { get; set; }
        public string Precio { get; set; }
        public string Total { get; set; }
    }
}