﻿namespace Entidades
{
    public class ProductoCatalogo
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Precio { get; set; }
        public string RutaImagen { get; set; }
    }
}